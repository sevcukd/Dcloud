package com.company;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("enter graph length:");
        int in = sc.nextInt();
        Graph g = new Graph(in);
        show(g);
        while (true)
        {
            System.out.print("1 - set length, 2 - add connection, 3 - delete connection, 4 - get children, 5 - set node name, 6 - get node by id, 7 - get node by name, 8 - is there any route, 9 - stop");
            switch (sc.next())
            {
                case "1":
                {
                    System.out.println("enter new length:");
                    int ind = sc.nextInt();
                    g = new Graph(g, ind);
                    break;
                }
                case "2":
                {
                    System.out.println("first:");
                    int ind = sc.nextInt();
                    System.out.println("second:");
                    int ind2 = sc.nextInt();
                    g.addConnection(ind-1, ind2-1);
                    break;
                }
                case "3":
                {
                    System.out.println("first:");
                    int ind = sc.nextInt();
                    System.out.println("second:");
                    int ind2 = sc.nextInt();
                    g.deleteConnection(ind-1, ind2-1);
                    break;
                }
                case "4":
                {
                    System.out.println("choose node:");
                    int ind = sc.nextInt();
                    ArrayList<Integer> ch = g.getChildNodes(ind-1);
                    if (ch.isEmpty()) System.out.println("this node hasn't any child nodes.");
                    else
                    {
                        System.out.print("child nodes: ");
                        for (int i:ch)
                        {
                            System.out.print(i+" ");
                        }
                        System.out.print("\n");
                    }
                    break;
                }
                case "5":
                {
                    System.out.println("id:");
                    int ind = sc.nextInt();
                    System.out.println("name:");
                    String str = sc.next();
                    g.setName(ind-1, str);
                    break;
                }
                case "6":
                {
                    System.out.println("id:");
                    int ind = sc.nextInt();
                    System.out.println(g.getName(ind-1));
                    break;
                }
                case "7":
                {
                    System.out.println("name:");
                    String str = sc.next();
                    System.out.println(g.idOf(str)+1);
                    break;
                }
                case "8":
                {
                    System.out.println("first:");
                    int ind = sc.nextInt();
                    System.out.println("second:");
                    int ind2 = sc.nextInt();
                    if (g.route(ind-1, ind2-1)) System.out.println("route between "+ind+" and "+ind2+" exists.");
                    else System.out.println("route between "+ind+" and "+ind2+" doesn't exist.");
                    break;
                }
                case "9":
                    sc.close();
                    return;
            }
            show(g);
        }
    }
    static void show(Graph g)
    {
        for (int i=0; i<g.n;i++)
        {
            for (int j=0; j<g.n;j++)
            {
                System.out.print(g.m[i][j]+" ");
            }
            System.out.print("\n");
        }
        for (String str : g.names)
        {
            System.out.print(str+" ");
        }
        System.out.print("\n");
    }

}

