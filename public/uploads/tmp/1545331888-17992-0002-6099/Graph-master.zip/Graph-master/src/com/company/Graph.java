package com.company;

import java.util.ArrayList;

public class Graph {
    int m[][];
    int n=0;
    String[] names;

    Graph (int n)
    {
        m = new int[n][n];
        this.n= n;
        names = new String[n];
    }
    Graph (Graph g, int newlength)
    {
        m = new int[newlength][newlength];
        n = newlength;
        names = new String[n];
        for (int i=0; i<newlength; i++)
        {
            if (i<g.n) names[i] = g.names[i];
            for (int j=0; j<newlength; j++)
            {
                if (i<g.n && j<g.n)
                    m[i][j] = g.m[i][j];
                else m[i][j] = 0;
            }
        }
    }
    public void addConnection(int a, int b)
    {
        m[a][b] = 1;
    }
    public void deleteConnection(int a, int b)
    {
        m[a][b] = 0;
    }
    public void setName (int id, String name)
    {
        names[id]=name;
    }
    public String getName (int id)
    {
        return names[id];
    }
    public int idOf(String name)
    {
        for (int i=0;i<names.length;i++)
        {
            try
            {
                if (names[i].equals(name)) return i;
            }
            catch (NullPointerException exc) {}
        }
        return -1;
    }

    public ArrayList<Integer> getChildNodes(int a)
    {
        ArrayList<Integer> res = new ArrayList<>();
        for (int j=0; j<n;j++)
            if (m[a][j]==1) res.add(j+1);
        return res;
    }
    public boolean route (int a, int b)
    {
        int[][] c = copy(m);
        for (int k=0; k<n; k++)
            for (int i=0; i<n; i++)
                for (int j=0; j<n; j++)
                {
                    if (c[i][k]>0 && c[k][j]>0 && i!=j)
                        if (c[i][k]+c[k][j]<c[i][j] || c[i][j]==0)
                        {
                            c[i][j]=c[i][k]+c[k][j];
                        }
                }
        return c[a][b]>0;
    }

    private int[][] copy (int[][] a)
    {
        int[][] res = new int[a.length][a.length];
        for (int i=0; i<n; i++)
            for (int j=0; j<n; j++)
                res[i][j]=a[i][j];
        return res;
    }
}

