package datsiuk.evgenii.mycalculator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends Activity {
    String str1 = "";
    String str2 = "";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button c = findViewById(R.id.button1);
        Button n1 = findViewById(R.id.button2);
        Button n4 = findViewById(R.id.button3);
        Button n7 = findViewById(R.id.button4);
        Button openBracket = findViewById(R.id.button5);
        Button backspace = findViewById(R.id.button6);
        Button n2 = findViewById(R.id.button7);
        Button n5 = findViewById(R.id.button8);
        Button n8 = findViewById(R.id.button9);
        Button n0 = findViewById(R.id.button10);
        Button dot = findViewById(R.id.button11);
        Button n3 = findViewById(R.id.button12);
        Button n6 = findViewById(R.id.button13);
        Button n9 = findViewById(R.id.button14);
        Button closeBracket = findViewById(R.id.button15);
        Button divide = findViewById(R.id.button16);
        Button multiply = findViewById(R.id.button17);
        Button minus = findViewById(R.id.button18);
        Button plus = findViewById(R.id.button19);
        Button result = findViewById(R.id.button20);
        final TextView view1 = findViewById(R.id.textView2);
        final TextView view2 = findViewById(R.id.textView1);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1 = "";
                view1.setText(str1);
            }
        });
        n1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="1";
                view1.setText(str1);
            }
        });
        n2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="2";
                view1.setText(str1);

            }
        });
        n3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="3";
                view1.setText(str1);
            }
        });
        n4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="4";
                view1.setText(str1);
            }
        });
        n5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="5";
                view1.setText(str1);
            }
        });
        n6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="6";
                view1.setText(str1);
            }
        });
        n7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="7";
                view1.setText(str1);
            }
        });
        n8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="8";
                view1.setText(str1);
            }
        });
        n9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="9";
                view1.setText(str1);
            }
        });
        n0.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="0";
                view1.setText(str1);
            }
        });
        openBracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+="(";
                view1.setText(str1);
            }
        });
        closeBracket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                str1+=")";
                view1.setText(str1);
            }
        });
        backspace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else
                {
                    str1 = str1.substring(0,str1.length()-1);
                    view1.setText(str1);
                }
            }
        });
        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String empty ="";
                if(str1.equals(empty))
                {
                    str1="0.";
                    view1.setText(str1);
                    return;
                }
                if(str1.substring(str1.length()-1).equals("/")||
                        str1.substring(str1.length()-1).equals("*")||
                        str1.substring(str1.length()-1).equals("+")||
                        str1.substring(str1.length()-1).equals("-")
                        )
                {
                    str1+="0.";
                    view1.setText(str1);
                    return;
                }
                for(int i=str1.length()-1;i>=0;i--)
                {
                    if(str1.substring(i,i+1).equals("+")||
                            str1.substring(i,i+1).equals("-")||
                            str1.substring(i,i+1).equals("*")||
                            str1.substring(i,i+1).equals("/"))
                    {

                        for(int j=str1.length()-1;j>=i;j--)
                        {
                            if(str1.substring(j,j+1).equals("."))
                            {
                                return;
                            }
                        }
                        break;
                    }
                    if(!str1.contains("+") &&
                            !str1.contains("-") &&
                            !str1.contains("*") &&
                            !str1.contains("/"))
                    {
                        String str3 = str1;
                        for(int j=0;j<str3.length();j++)
                        {
                            if(str3.substring(j,j+1).equals("."))
                            {
                                return;
                            }
                        }
                    }
                }

                str1+=".";
                view1.setText(str1);
            }
        });
        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else if(str1.substring(str1.length()-1).equals("/")||
                        str1.substring(str1.length()-1).equals("*")||
                        str1.substring(str1.length()-1).equals("+")||
                        str1.substring(str1.length()-1).equals("-"))
                {
                    str1=str1.substring(0,str1.length()-1);
                    str1+="/";
                    view1.setText(str1);
                    return;
                }
                else str1+="/";
                view1.setText(str1);
            }
        });
        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else if(str1.substring(str1.length()-1).equals("/")||
                        str1.substring(str1.length()-1).equals("*")||
                        str1.substring(str1.length()-1).equals("+")||
                        str1.substring(str1.length()-1).equals("-"))
                {
                    str1=str1.substring(0,str1.length()-1);
                    str1+="*";
                    view1.setText(str1);
                    return;
                }
                else str1+="*";
                view1.setText(str1);
            }
        });
        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else if(str1.substring(str1.length()-1).equals("/")||
                        str1.substring(str1.length()-1).equals("*")||
                        str1.substring(str1.length()-1).equals("+")||
                        str1.substring(str1.length()-1).equals("-"))
                {
                    str1=str1.substring(0,str1.length()-1);
                    str1+="-";
                    view1.setText(str1);
                    return;
                }
                else str1+="-";
                view1.setText(str1);
            }
        });
        plus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else if(str1.substring(str1.length()-1).equals("/")||
                        str1.substring(str1.length()-1).equals("*")||
                        str1.substring(str1.length()-1).equals("+")||
                        str1.substring(str1.length()-1).equals("-"))
                {
                    str1=str1.substring(0,str1.length()-1);
                    str1+="+";
                    view1.setText(str1);
                    return;
                }
                else str1+="+";
                view1.setText(str1);
            }
        });
        result.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                if(str1.equals(""))
                {
                    return;
                }
                else {
                    //Calculate calculate = new Calculate();
                    str2+=str1+"\n";
                    view2.setMovementMethod(new ScrollingMovementMethod());
                    view2.setText(str2);
                    str1=Double.toString(Calculate.eval(str1));
                    view1.setText(Double.toString(Calculate.eval(str1)));
                }
            }
        });



    }
}