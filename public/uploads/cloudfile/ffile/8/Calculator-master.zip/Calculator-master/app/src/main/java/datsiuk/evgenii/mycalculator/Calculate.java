package datsiuk.evgenii.mycalculator;

import java.util.LinkedList;

public class Calculate {
    static double eval(String s) {
        LinkedList<Double> st = new LinkedList<Double>();
        LinkedList<Character> op = new LinkedList<Character>();
        s=s.replaceAll("-\\(", "+(-1)*(");
        if ("+-*/%^".indexOf(s.charAt(0)) != -1) s="0"+s;
        System.out.println("equation = " + s);
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch==' ') continue;
            if (ch == '(')
                op.add('(');
            else if (ch == ')') {
                while (op.getLast() != '(')
                    calculate(st,op.removeLast());
                op.removeLast();
            } else if (ch == '!'){
                st.add(factorial(st.removeLast()));
            } else if ("+-*/%^".indexOf(ch) != -1) { //якщо символ є оператором
                if ("+-*/%^".indexOf(s.charAt(i+1)) == -1) //наступний елемент є операнд
                    while (!op.isEmpty() && priority(op.getLast()) >= priority(ch)) //якщо операторський стек не порожній І пріоритет останньї операції стеку >= пріоритету цієї операції
                        calculate(st, op.removeLast()); //передаю стек і останню операцію

                if (s.charAt(i-1) != '(') //якщо попередній символ рядка не "("
                    op.add(ch); //додати цей символ у стек операторів
            } else {
                double[] arr = getOperand(i, s);
                i = (int)arr[0];
                st.add(arr[1]);
                i--;
            }
        }

        while (op.size()!=0) calculate(st, op.removeLast());

        return st.get(0);
    }

    private static double[] getOperand(int i, String s) {
        StringBuilder operand = new StringBuilder();
        int a = i-1;

        try {
            if (s.charAt(a) == '-' && "+-*/%^(".indexOf(s.charAt(a-1)) != -1)
                operand.append('-');
        } catch (Exception e){
            a = 0;
        } finally {
            while (i < s.length() && (Character.isDigit(s.charAt(i)) || s.charAt(i) == '.'))
                operand.append(s.charAt(i++));
        }

        return new double[]{i, Double.parseDouble(operand.toString())};
    }

    private static double factorial(double n) {
        return (n == 1 || n == 0)? 1 : n * factorial(n-1);
    }

    private static int priority(char op) {
        switch (op) {
            case '+':return 1;
            case '-':return 1;
            case '*':return 2;
            case '/':return 2;
            case '^':return 2;
            case '%':return 2;
            default:return -1;
        }
    }

    private static void calculate(LinkedList<Double> st, char op) {
        Double right = st.removeLast(), left = st.removeLast();
        switch (op) {
            case '+':{st.add(left + right);break;}
            case '-':{st.add(left - right);break;}
            case '*':{st.add(left * right);break;}
            case '/':{st.add(left / right);break;}
            case '^':{st.add(Math.pow(left,right));break;}
            case '%':{st.add(left % right);break;}
        }
    }

}